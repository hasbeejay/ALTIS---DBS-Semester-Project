using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Announcement
{
    public class ListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
