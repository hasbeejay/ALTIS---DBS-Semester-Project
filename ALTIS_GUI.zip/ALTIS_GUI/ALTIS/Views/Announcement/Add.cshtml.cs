using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Announcement
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
