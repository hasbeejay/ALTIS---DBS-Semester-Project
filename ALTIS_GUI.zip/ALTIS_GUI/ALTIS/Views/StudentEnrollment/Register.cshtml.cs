using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentEnrollment
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
