using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentEnrollment
{
    public class MyClassroomModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
