using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Students
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
