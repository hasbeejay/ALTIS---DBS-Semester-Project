using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Students
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
