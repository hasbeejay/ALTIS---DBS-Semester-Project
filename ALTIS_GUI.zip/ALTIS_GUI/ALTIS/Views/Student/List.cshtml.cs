using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Students
{
    public class ListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
