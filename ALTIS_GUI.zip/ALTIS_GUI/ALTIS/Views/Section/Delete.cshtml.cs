using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Section
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
