using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Attendence
{
    public class SelectClassroomModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
