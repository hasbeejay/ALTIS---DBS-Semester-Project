using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Attendence
{
    public class MarkModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
