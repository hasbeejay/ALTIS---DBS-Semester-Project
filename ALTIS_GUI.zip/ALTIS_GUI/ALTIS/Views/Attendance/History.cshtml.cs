using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Attendance
{
    public class HistoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
