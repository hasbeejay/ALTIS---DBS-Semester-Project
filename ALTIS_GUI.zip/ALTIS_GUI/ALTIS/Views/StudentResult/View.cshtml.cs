using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentResult
{
    public class ViewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
