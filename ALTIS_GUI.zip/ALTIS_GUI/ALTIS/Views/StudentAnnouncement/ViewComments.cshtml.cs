using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentAnnouncement
{
    public class ViewCommentsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
