using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Results
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
