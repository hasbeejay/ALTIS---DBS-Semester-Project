using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentAttendance
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
