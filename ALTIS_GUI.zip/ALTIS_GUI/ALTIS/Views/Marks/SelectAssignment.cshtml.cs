using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Marks
{
    public class SelectAssignmentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
