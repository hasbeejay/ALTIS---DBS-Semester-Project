using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Marks
{
    public class GradeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
