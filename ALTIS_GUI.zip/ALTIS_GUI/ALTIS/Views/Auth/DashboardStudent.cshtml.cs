using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Auth
{
    public class DashboardStudentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
