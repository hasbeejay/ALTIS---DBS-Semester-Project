using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Auth
{
    public class DashboardFacultyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
