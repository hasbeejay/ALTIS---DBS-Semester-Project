using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentAssignment
{
    public class SubmitModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
