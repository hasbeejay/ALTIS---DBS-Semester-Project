using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.StudentAssignment
{
    public class ListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
