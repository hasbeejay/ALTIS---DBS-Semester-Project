using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ALTIS.Views.Faculty
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
