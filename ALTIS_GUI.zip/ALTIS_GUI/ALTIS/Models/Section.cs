﻿namespace ALTIS.Models
{
    public class Section
    {
        public string SectionID { get; set; }
        public string SectionName { get; set; }
    }
}
