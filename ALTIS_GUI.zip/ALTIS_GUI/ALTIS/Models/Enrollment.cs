﻿namespace ALTIS.Models
{
    public class Enrollment
    {
        public int EnrollmentID { get; set; }
        public int StudentID { get; set; }
        public int ClassroomID { get; set; }
    }
}
