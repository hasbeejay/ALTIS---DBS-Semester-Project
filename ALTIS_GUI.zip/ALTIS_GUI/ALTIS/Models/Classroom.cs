﻿namespace ALTIS.Models
{
    public class Classroom
    {
        public int ClassroomID { get; set; }
        public string Title { get; set; }
        public int CourseID { get; set; }
        public int FacultyID { get; set; }
        public string SectionID { get; set; }
    }
}
